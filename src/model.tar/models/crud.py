"""CRUD operations for database models."""

from datetime import datetime
from typing import Any, Dict, List, Optional, Type, TypeVar

from sqlalchemy.orm import Session

from src.models.database import AudioOutput, Base, Script, VoiceProfile

# Generic type for database models
ModelType = TypeVar("ModelType", bound=Base)


class CRUDBase:
    """Base class for CRUD operations."""

    def __init__(self, model: Type[ModelType]):
        """Initialize with model class."""
        self.model = model

    def get(self, db: Session, id: int) -> Optional[ModelType]:
        """Get a single record by ID."""
        return db.query(self.model).filter(self.model.id == id).first()

    def get_multi(
        self, db: Session, *, skip: int = 0, limit: int = 100
    ) -> List[ModelType]:
        """Get multiple records with pagination."""
        return db.query(self.model).offset(skip).limit(limit).all()

    def create(self, db: Session, *, obj_in: Dict[str, Any]) -> ModelType:
        """Create a new record."""
        db_obj = self.model(**obj_in)
        db.add(db_obj)
        db.commit()
        db.refresh(db_obj)
        return db_obj

    def update(
        self, db: Session, *, db_obj: ModelType, obj_in: Dict[str, Any]
    ) -> ModelType:
        """Update an existing record."""
        for field, value in obj_in.items():
            if hasattr(db_obj, field):
                setattr(db_obj, field, value)
        
        # Update the updated_at timestamp if it exists
        if hasattr(db_obj, "updated_at"):
            db_obj.updated_at = datetime.utcnow()
        
        db.add(db_obj)
        db.commit()
        db.refresh(db_obj)
        return db_obj

    def delete(self, db: Session, *, id: int) -> Optional[ModelType]:
        """Delete a record."""
        obj = self.get(db, id)
        if obj:
            db.delete(obj)
            db.commit()
        return obj


class CRUDVoiceProfile(CRUDBase):
    """CRUD operations for VoiceProfile model."""

    def get_by_name(self, db: Session, *, name: str) -> Optional[VoiceProfile]:
        """Get voice profile by name."""
        return db.query(VoiceProfile).filter(VoiceProfile.name == name).first()

    def get_all_with_outputs(self, db: Session) -> List[VoiceProfile]:
        """Get all voice profiles with their audio outputs."""
        return db.query(VoiceProfile).all()

    def update_parameters(
        self, db: Session, *, id: int, parameters: Dict[str, Any]
    ) -> Optional[VoiceProfile]:
        """Update voice profile parameters."""
        voice_profile = self.get(db, id)
        if voice_profile:
            # Merge new parameters with existing ones
            current_params = voice_profile.parameters or {}
            current_params.update(parameters)
            return self.update(db, db_obj=voice_profile, obj_in={"parameters": current_params})
        return None


class CRUDScript(CRUDBase):
    """CRUD operations for Script model."""

    def get_by_title(self, db: Session, *, title: str) -> Optional[Script]:
        """Get script by title."""
        return db.query(Script).filter(Script.title == title).first()

    def get_versions(self, db: Session, *, parent_id: int) -> List[Script]:
        """Get all versions of a script."""
        return db.query(Script).filter(Script.parent_id == parent_id).all()

    def create_version(
        self, db: Session, *, script_id: int, content: str
    ) -> Optional[Script]:
        """Create a new version of an existing script."""
        original = self.get(db, script_id)
        if not original:
            return None

        # Get the latest version number
        versions = self.get_versions(db, parent_id=original.parent_id or original.id)
        latest_version = max([v.version for v in versions] + [original.version])

        # Create new version
        new_version = {
            "title": original.title,
            "content": content,
            "version": latest_version + 1,
            "parent_id": original.parent_id or original.id,
        }
        return self.create(db, obj_in=new_version)

    def search(self, db: Session, *, query: str) -> List[Script]:
        """Search scripts by title or content."""
        search_filter = f"%{query}%"
        return (
            db.query(Script)
            .filter(
                (Script.title.like(search_filter)) | (Script.content.like(search_filter))
            )
            .all()
        )


class CRUDAudioOutput(CRUDBase):
    """CRUD operations for AudioOutput model."""

    def get_by_script(self, db: Session, *, script_id: int) -> List[AudioOutput]:
        """Get all audio outputs for a script."""
        return db.query(AudioOutput).filter(AudioOutput.script_id == script_id).all()

    def get_by_voice_profile(
        self, db: Session, *, voice_profile_id: int
    ) -> List[AudioOutput]:
        """Get all audio outputs for a voice profile."""
        return (
            db.query(AudioOutput)
            .filter(AudioOutput.voice_profile_id == voice_profile_id)
            .all()
        )

    def get_recent(self, db: Session, *, limit: int = 10) -> List[AudioOutput]:
        """Get recent audio outputs."""
        return (
            db.query(AudioOutput)
            .order_by(AudioOutput.created_at.desc())
            .limit(limit)
            .all()
        )


# Create instances for each model
voice_profile = CRUDVoiceProfile(VoiceProfile)
script = CRUDScript(Script)
audio_output = CRUDAudioOutput(AudioOutput)