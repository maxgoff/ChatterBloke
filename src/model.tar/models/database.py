"""Database models and connection management for ChatterBloke."""

from datetime import datetime
from typing import Any, Dict, Optional

from sqlalchemy import (
    JSON,
    Boolean,
    Column,
    DateTime,
    ForeignKey,
    Integer,
    String,
    create_engine,
)
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship, sessionmaker
from sqlalchemy.pool import StaticPool

from src.utils.config import get_settings

# Create base class for declarative models
Base = declarative_base()


class VoiceProfile(Base):
    """Voice profile model for storing cloned voice information."""

    __tablename__ = "voice_profiles"

    id = Column(Integer, primary_key=True)
    name = Column(String(255), nullable=False, unique=True)
    description = Column(String(500))
    audio_file_path = Column(String(500))
    model_path = Column(String(500))
    is_cloned = Column(Boolean, default=False)
    parameters = Column(JSON, default=dict)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    audio_outputs = relationship(
        "AudioOutput", back_populates="voice_profile", cascade="all, delete-orphan"
    )

    def __repr__(self) -> str:
        """String representation."""
        return f"<VoiceProfile(id={self.id}, name='{self.name}')>"

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "id": self.id,
            "name": self.name,
            "description": self.description,
            "audio_file_path": self.audio_file_path,
            "model_path": self.model_path,
            "is_cloned": self.is_cloned,
            "parameters": self.parameters,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
        }


class Script(Base):
    """Script model for storing text content."""

    __tablename__ = "scripts"

    id = Column(Integer, primary_key=True)
    title = Column(String(255), nullable=False)
    content = Column(String)  # SQLite stores as TEXT
    version = Column(Integer, default=1)
    parent_id = Column(Integer, ForeignKey("scripts.id"), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    audio_outputs = relationship(
        "AudioOutput", back_populates="script", cascade="all, delete-orphan"
    )
    parent = relationship("Script", remote_side=[id], backref="versions")

    def __repr__(self) -> str:
        """String representation."""
        return f"<Script(id={self.id}, title='{self.title}', version={self.version})>"

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "id": self.id,
            "title": self.title,
            "content": self.content,
            "version": self.version,
            "parent_id": self.parent_id,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
        }


class AudioOutput(Base):
    """Audio output model for storing generated speech files."""

    __tablename__ = "audio_outputs"

    id = Column(Integer, primary_key=True)
    script_id = Column(Integer, ForeignKey("scripts.id"), nullable=False)
    voice_profile_id = Column(Integer, ForeignKey("voice_profiles.id"), nullable=False)
    file_path = Column(String(500), nullable=False)
    parameters = Column(JSON, default=dict)
    created_at = Column(DateTime, default=datetime.utcnow)

    # Relationships
    script = relationship("Script", back_populates="audio_outputs")
    voice_profile = relationship("VoiceProfile", back_populates="audio_outputs")

    def __repr__(self) -> str:
        """String representation."""
        return f"<AudioOutput(id={self.id}, script_id={self.script_id}, voice_profile_id={self.voice_profile_id})>"

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "id": self.id,
            "script_id": self.script_id,
            "voice_profile_id": self.voice_profile_id,
            "file_path": self.file_path,
            "parameters": self.parameters,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }


# Database connection management
_engine: Optional[Any] = None
_SessionLocal: Optional[sessionmaker] = None


def get_engine():
    """Get or create database engine."""
    global _engine
    if _engine is None:
        settings = get_settings()
        # Use StaticPool for SQLite to avoid connection issues
        connect_args = {"check_same_thread": False} if "sqlite" in settings.database_url else {}
        poolclass = StaticPool if "sqlite" in settings.database_url else None
        
        _engine = create_engine(
            settings.database_url,
            connect_args=connect_args,
            poolclass=poolclass,
            echo=settings.debug,
        )
    return _engine


def get_session_factory() -> sessionmaker:
    """Get or create session factory."""
    global _SessionLocal
    if _SessionLocal is None:
        _SessionLocal = sessionmaker(
            autocommit=False, autoflush=False, bind=get_engine()
        )
    return _SessionLocal


def get_db():
    """Get database session for dependency injection."""
    SessionLocal = get_session_factory()
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def init_db() -> None:
    """Initialize database tables."""
    engine = get_engine()
    Base.metadata.create_all(bind=engine)


def reset_db() -> None:
    """Reset database (useful for testing)."""
    global _engine, _SessionLocal
    if _engine is not None:
        Base.metadata.drop_all(bind=_engine)
        _engine.dispose()
    _engine = None
    _SessionLocal = None